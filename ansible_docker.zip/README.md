# ansible_docker
Тестовое задание Betting Software
